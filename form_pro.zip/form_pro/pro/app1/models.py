from django.db import models
from django.contrib.auth.models import AbstractUser
# Create your models here.
class student(models.Model):
    rollno = models.IntegerField()
    name = models.CharField(max_length=20)
    image =models.ImageField(upload_to='data/photos/')
    files = models.FileField(upload_to='data/files',null=True,blank=True)

class CustomUser(AbstractUser):
    email=models.CharField(max_length=100)
   
