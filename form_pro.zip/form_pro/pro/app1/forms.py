from django import forms
from app1.models import student
from app1.models import CustomUser
from django.contrib.auth.forms import UserCreationForm
class studentForm(forms.ModelForm):
    class Meta:
        model = student
        fields = '__all__'


class CustomUserCreationForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model=CustomUser
        fields=UserCreationForm.Meta.fields+('email')

