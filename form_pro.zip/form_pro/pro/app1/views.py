from django.shortcuts import render
from app1.models import student
from app1.forms import studentForm
from app1.forms import CustomUserCreationForm
# Create your views here.
def list(request):
    k = student.objects.all()
    return render(request, 'list.html', {"s": k})
#### user-defined form without using objects
def form1(request):
    if(request.method=='POST'):
        form = studentForm(request.POST)
        if form.is_valid():
            form.save()
            return list(request)
    return render(request, 'form1.html')

#### user-defined form with using objects
def form1(request):
    if(request.method=='POST'):
        r=request.POST['rollno']
        n=request.POST['name']
        i=request.FILES['image']
        f=request.FILES['files']
        o=student.objects.create(rollno=r,name=n,image=i,files=f)
        o.save()
        return list(request)
    return render(request, 'form1.html')
def home(request):
    return render(request,"home.html")
def base(request):
    return render(request,"base.html")
def sigin_up(request):
    form=CustomUserCreationForm()     #Empty form Object
    if(request.method=="POST"):
        form=CustomUserCreationForm(request.POST)
        if(form.is_valid()):
            form.save()
            return home(request)
    return render(request,'siginup.html',{'form':form})
   